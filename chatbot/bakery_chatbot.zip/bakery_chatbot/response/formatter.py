# response/formatter.py — Format output chatbot agar bersih & mudah dibaca

from config import CHATBOT_CONFIG

CURRENCY = CHATBOT_CONFIG["currency_symbol"]
SHOP     = CHATBOT_CONFIG["shop_name"]


def fmt_price(price) -> str:
    """Rp 24.000"""
    try:
        return f"{CURRENCY} {int(price):,}".replace(",", ".")
    except (TypeError, ValueError):
        return "-"


def fmt_rating(rating) -> str:
    if rating is None:
        return "Belum ada rating"
    try:
        r = float(rating)
        stars = "★" * int(r) + "☆" * (5 - int(r))
        return f"{stars} ({r:.1f})"
    except (TypeError, ValueError):
        return "-"


def fmt_sold(sold) -> str:
    if sold is None:
        return "0 terjual"
    return f"{int(sold):,} terjual".replace(",", ".")


# ── Tabel produk ──────────────────────────────────────────────────────────────

def table_products(rows: list[dict], title: str = "Produk") -> str:
    if not rows:
        return "😔 Tidak ada produk yang ditemukan."

    lines = [f"\n📋 {title} ({len(rows)} produk)\n"]
    lines.append("─" * 60)

    for i, r in enumerate(rows, 1):
        name     = r.get("name", "-")
        price    = fmt_price(r.get("price"))
        rating   = fmt_rating(r.get("rating"))
        category = r.get("category", "-")
        total_sold = r.get("total_sold")
        sold       = fmt_sold(total_sold if total_sold is not None else r.get("sold"))

        lines.append(f"{i:>2}. {name}")
        lines.append(f"     💰 {price}  |  📂 {category}")
        lines.append(f"     {rating}  |  🛒 {sold}")
        lines.append("")

    lines.append("─" * 60)
    return "\n".join(lines)


def detail_product(rows: list[dict]) -> str:
    if not rows:
        return "😔 Produk tidak ditemukan. Coba cek ejaan nama produk."

    lines = []
    for r in rows:
        lines.append(f"\n🍞 {r.get('name', '-')}")
        lines.append("─" * 40)
        lines.append(f"📂 Kategori  : {r.get('category', '-')}")
        lines.append(f"💰 Harga     : {fmt_price(r.get('price'))}")
        lines.append(f"⭐ Rating    : {fmt_rating(r.get('rating'))}")
        lines.append(f"🛒 Terjual   : {fmt_sold(r.get('sold'))}")
        lines.append(f"📝 Deskripsi : {r.get('description', '-')}")
        lines.append("")
    return "\n".join(lines)


def stock_result(rows: list[dict]) -> str:
    if not rows:
        return "😔 Produk tidak ditemukan di database."
    lines = ["\n📦 Status Stok\n" + "─" * 40]
    for r in rows:
        status_icon = "✅" if r.get("status") == "Tersedia" else "❌"
        lines.append(f"{status_icon} {r['name']} — {r.get('status','?')}")
        lines.append(f"   💰 {fmt_price(r.get('price'))}")
    return "\n".join(lines)


# ── Respons teks ──────────────────────────────────────────────────────────────

def help_message() -> str:
    return f"""
╔══════════════════════════════════════╗
║  {SHOP:^36} ║
║  🤖 Panduan Chatbot                  ║
╚══════════════════════════════════════╝

Anda bisa tanya:

🍞 PRODUK
  • "tampilkan semua produk"
  • "ada produk apa saja?"

💰 HARGA
  • "produk termurah"
  • "produk termahal"
  • "harga di bawah 25000"
  • "produk antara 15000 sampai 30000"

⭐ RATING
  • "produk rating terbaik"
  • "produk paling bagus"

🛒 TERLARIS
  • "produk terlaris"
  • "paling banyak dibeli"
  • "rekomendasiin dong"

📂 KATEGORI
  • "tampilkan donat"
  • "produk pastry apa saja"
  • "ada roti manis?"

🔍 DETAIL
  • "info croissant butter"
  • "detail donat glazed"
  • "stok croissant almond ada gak?"

Ketik 'exit' atau 'keluar' untuk berhenti.
"""


def unknown_response() -> str:
    return (
        "🤔 Maaf, saya belum mengerti pertanyaan Anda.\n"
        "Coba tanyakan: produk termurah, terlaris, rating terbaik,\n"
        "atau ketik 'bantuan' untuk panduan lengkap."
    )


def low_confidence_response(tag: str, score: float) -> str:
    return (
        f"🤔 Saya kurang yakin dengan pertanyaan Anda (skor: {score:.0%}).\n"
        f"Ketik 'bantuan' untuk melihat contoh pertanyaan."
    )
