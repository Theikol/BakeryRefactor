# bot/chatbot.py — Engine utama chatbot bakery

import random
from config import CHATBOT_CONFIG
from nlp.preprocessor import preprocess
from nlp.classifier import IntentClassifier
from nlp.entity_extractor import EntityExtractor
from db.connection import DatabaseConnection
from db.query_builder import QueryBuilder
from response import formatter as fmt

THRESHOLD = CHATBOT_CONFIG["confidence_threshold"]
SHOP      = CHATBOT_CONFIG["shop_name"]


class BakeryChatbot:
    """
    Chatbot produk bakery — tanpa API AI eksternal.
    Semua NLP berjalan lokal dengan TF-IDF + keyword matching.
    """

    def __init__(self):
        self.classifier = IntentClassifier(
            model_path=CHATBOT_CONFIG["model_path"]
        )
        self.db  = DatabaseConnection()
        self.qb  = None
        self.ext = EntityExtractor()
        self._product_names: list[str] = []

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def start(self) -> None:
        """Sambungkan DB, load model, dan fetch product names."""
        self.db.connect()
        self.qb = QueryBuilder(self.db)
        try:
            self.classifier.load()
        except RuntimeError:
            print("[Bot] Model belum ada, melatih otomatis...")
            self.classifier.train()

        self._refresh_product_names()
        print(f"\n[Bot] {SHOP} siap! Ketik 'bantuan' untuk panduan.\n")

    def stop(self) -> None:
        self.db.disconnect()

    def _refresh_product_names(self) -> None:
        self._product_names = self.qb.all_product_names()
        self.ext.update_products(self._product_names)

    # ── Main chat method ──────────────────────────────────────────────────────

    def chat(self, user_input: str) -> str:
        """Proses satu pesan user dan kembalikan respons teks."""

        # 1. Preprocessing
        proc   = preprocess(user_input, known_words=self._product_names)
        clean  = proc["clean"]
        joined = proc["joined"]

        # 2. Klasifikasi intent
        tag, score = self.classifier.predict(clean)

        # 3. Ekstrak entitas
        entities = self.ext.extract(clean)

        # 4. Route ke handler
        return self._route(tag, score, entities, joined)

    # ── Router ────────────────────────────────────────────────────────────────

    def _route(self, tag: str, score: float, entities: dict, raw_clean: str) -> str:
        if score < THRESHOLD and tag not in ("greeting", "farewell", "help"):
            return fmt.unknown_response()

        handlers = {
            "greeting":       self._handle_greeting,
            "farewell":       self._handle_farewell,
            "help":           self._handle_help,
            "list_products":  self._handle_list,
            "best_seller":    self._handle_best_seller,
            "cheapest":       self._handle_cheapest,
            "most_expensive": self._handle_expensive,
            "best_rating":    self._handle_rating,
            "category_search":self._handle_category,
            "price_range":    self._handle_price_range,
            "product_detail": self._handle_detail,
            "stock_check":    self._handle_stock,
        }

        handler = handlers.get(tag)
        if handler:
            return handler(entities)

        return fmt.unknown_response()

    # ── Handlers ──────────────────────────────────────────────────────────────

    def _handle_greeting(self, _: dict) -> str:
        responses = [
            f"Halo! Selamat datang di {SHOP} 🍞\nAda yang bisa saya bantu?",
            f"Hai! Saya siap membantu Anda menemukan produk favorit di {SHOP} 😊",
            "Halo! Tanyakan tentang produk, harga, atau rekomendasi kami!",
        ]
        return random.choice(responses)

    def _handle_farewell(self, _: dict) -> str:
        responses = [
            f"Terima kasih sudah berkunjung ke {SHOP}! Sampai jumpa 👋",
            "Sampai jumpa! Semoga hari Anda menyenangkan 😊",
            "Terima kasih! Jangan lupa mampir lagi ya 🍰",
        ]
        return random.choice(responses)

    def _handle_help(self, _: dict) -> str:
        return fmt.help_message()

    def _handle_list(self, _: dict) -> str:
        rows = self.qb.list_all_products()
        return fmt.table_products(rows, "Semua Produk Aktif")

    def _handle_best_seller(self, entities: dict) -> str:
        rows = self.qb.best_seller(category=entities.get("category"))
        title = "Produk Terlaris"
        if entities.get("category"):
            title += f" — {entities['category'].title()}"
        return fmt.table_products(rows, title)

    def _handle_cheapest(self, entities: dict) -> str:
        rows = self.qb.sort_by_price_asc(category=entities.get("category"))
        return fmt.table_products(rows, "Produk Harga Termurah → Termahal")

    def _handle_expensive(self, entities: dict) -> str:
        rows = self.qb.sort_by_price_desc(category=entities.get("category"))
        return fmt.table_products(rows, "Produk Harga Termahal → Termurah")

    def _handle_rating(self, entities: dict) -> str:
        rows = self.qb.sort_by_rating_desc(category=entities.get("category"))
        return fmt.table_products(rows, "Produk Rating Terbaik")

    def _handle_category(self, entities: dict) -> str:
        cat = entities.get("category")
        if not cat:
            return (
                "📂 Kategori yang tersedia: donat, pastry, roti-manis, "
                "roti-tawar, roti-gurih, kue, roti, lainnya.\n"
                "Contoh: 'tampilkan produk pastry'"
            )
        rows = self.qb.by_category(cat)
        return fmt.table_products(rows, f"Produk Kategori: {cat.title()}")

    def _handle_price_range(self, entities: dict) -> str:
        pmin = entities.get("price_min")
        pmax = entities.get("price_max")

        if pmin is None and pmax is None:
            # Tidak ada rentang → tampilkan semua urut harga
            rows = self.qb.sort_by_price_asc()
            return fmt.table_products(rows, "Semua Produk (Harga Terendah)")

        rows = self.qb.price_range(
            price_min=pmin,
            price_max=pmax,
            category=entities.get("category"),
        )
        label_min = fmt.fmt_price(pmin) if pmin else "0"
        label_max = fmt.fmt_price(pmax) if pmax else "∞"
        return fmt.table_products(rows, f"Produk Harga {label_min} – {label_max}")

    def _handle_detail(self, entities: dict) -> str:
        pname = entities.get("product_name")
        if not pname:
            return (
                "🔍 Sebutkan nama produknya ya!\n"
                "Contoh: 'detail croissant butter' atau 'info donat glazed'"
            )
        rows = self.qb.product_detail(pname)
        return fmt.detail_product(rows)

    def _handle_stock(self, entities: dict) -> str:
        pname = entities.get("product_name")
        if not pname:
            return (
                "🔍 Sebutkan nama produknya!\n"
                "Contoh: 'stok croissant almond ada gak?'"
            )
        rows = self.qb.check_stock(pname)
        return fmt.stock_result(rows)
