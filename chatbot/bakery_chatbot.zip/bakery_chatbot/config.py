# config.py — Konfigurasi utama chatbot

# ── Database ───────────────────────────────────────────────────────────────────
DB_CONFIG = {
    "host":     "localhost",
    "port":     3306,
    "user":     "root",
    "password": "",
    "database": "bakery_db",
    "charset":  "utf8mb4",
}

# ── Chatbot ────────────────────────────────────────────────────────────────────
CHATBOT_CONFIG = {
    "shop_name":            "Toko Roti Kami",
    "model_path":           "data/model/",
    "confidence_threshold": 0.30,   # skor minimum agar intent dianggap valid
    "max_results":          10,     # batas baris hasil query
    "currency_symbol":      "Rp",
}

# ── Kolom tabel products ───────────────────────────────────────────────────────
PRODUCT_COLUMNS = {
    "id":          "id",
    "name":        "name",
    "category":    "category",
    "price":       "price",
    "image":       "image",
    "description": "description",
    "rating":      "rating",
    "sold":        "sold",
    "is_active":   "is_active",
}
