# nlp/synonyms.py — Kamus sinonim untuk chatbot bakery Indonesia

# ── Kategori produk ────────────────────────────────────────────────────────────
CATEGORY_SYNONYMS: dict[str, list[str]] = {
    "donat":      ["donut", "donuts", "donat", "glazed", "donat glazed"],
    "pastry":     ["pastri", "croissant", "eclair", "pain", "kue lapis"],
    "roti-manis": ["roti manis", "sweet bread", "roti segar", "muffin", "cupcake"],
    "roti-tawar": ["roti tawar", "roti putih", "white bread", "bagel", "baguette", "gandum", "pandan"],
    "roti-gurih": ["roti gurih", "savory bread", "abon", "cream cheese"],
    "kue":        ["cake", "kue kering", "pastri manis", "cupcake", "brownies"],
    "lainnya":    ["other", "lain", "misc"],
    "roti":       ["bread", "brioche", "baguette"],
}

# ── Sort / filter keywords ─────────────────────────────────────────────────────
SORT_KEYWORDS: dict[str, list[str]] = {
    "price_asc":    [
        "termurah", "paling murah", "harga terendah", "murah dulu",
        "dari murah", "murah ke mahal", "ekonomis", "terjangkau", "hemat",
        "budget", "harga rendah", "urutkan murah"
    ],
    "price_desc":   [
        "termahal", "paling mahal", "harga tertinggi", "mahal dulu",
        "dari mahal", "mahal ke murah", "premium", "eksklusif",
        "harga tinggi", "urutkan mahal"
    ],
    "rating_desc":  [
        "rating terbaik", "rating tertinggi", "paling bagus", "terbagus",
        "kualitas terbaik", "nilai tertinggi", "bintang tertinggi",
        "rating tinggi", "paling disukai", "paling berkualitas"
    ],
    "sold_desc":    [
        "terlaris", "paling laris", "paling banyak dibeli", "best seller",
        "bestseller", "populer", "paling populer", "sering dibeli",
        "banyak dibeli", "favorit", "paling enak", "paling diminati",
        "rekomen", "rekomendasi", "top produk", "unggulan"
    ],
}

# ── Intent keywords (bobot deteksi) ───────────────────────────────────────────
INTENT_KEYWORDS: dict[str, list[str]] = {
    "greeting":     ["halo", "hai", "hi", "hello", "hei", "selamat", "assalamualaikum"],
    "farewell":     ["bye", "dadah", "sampai jumpa", "terima kasih", "makasih", "thanks", "keluar", "exit", "quit"],
    "help":         ["bantuan", "help", "bisa apa", "cara", "panduan", "fitur", "petunjuk"],
    "list":         ["semua", "daftar", "list", "katalog", "menu", "tampilkan", "lihat"],
    "best_seller":  ["terlaris", "laris", "populer", "best seller", "bestseller", "favorit", "enak", "rekomen", "paling banyak"],
    "cheapest":     ["murah", "termurah", "terjangkau", "ekonomis", "hemat", "budget", "rendah"],
    "expensive":    ["mahal", "termahal", "premium", "eksklusif", "tertinggi"],
    "rating":       ["rating", "bintang", "nilai", "bagus", "kualitas", "terbaik"],
    "category":     ["kategori", "jenis", "tipe", "donat", "pastry", "roti", "kue", "croissant", "muffin", "bagel", "eclair"],
    "price_range":  ["harga", "berapa", "kisaran", "antara", "sekitar", "di bawah", "di atas", "kurang dari"],
    "detail":       ["detail", "info", "informasi", "tentang", "deskripsi", "jelaskan", "apa itu"],
    "stock":        ["stok", "tersedia", "ready", "ada", "masih ada", "aktif"],
}

# ── Typo / informal corrections ───────────────────────────────────────────────
TYPO_MAP: dict[str, str] = {
    "brp":          "berapa",
    "gmn":          "gimana",
    "bs":           "bisa",
    "gk":           "tidak",
    "ga":           "tidak",
    "gak":          "tidak",
    "ngga":         "tidak",
    "nggak":        "tidak",
    "yg":           "yang",
    "lg":           "lagi",
    "lgi":          "lagi",
    "udh":          "sudah",
    "udah":         "sudah",
    "klo":          "kalau",
    "klu":          "kalau",
    "kalo":         "kalau",
    "ada ga":       "ada tidak",
    "ada gak":      "ada tidak",
    "donuts":       "donat",
    "donut":        "donat",
    "croisant":     "croissant",
    "croissan":     "croissant",
    "roti tawar":   "roti-tawar",
    "roti manis":   "roti-manis",
    "roti gurih":   "roti-gurih",
    "paling enak":  "terlaris",
    "paling bagus": "rating terbaik",
    "paling murah": "termurah",
    "paling mahal": "termahal",
}
