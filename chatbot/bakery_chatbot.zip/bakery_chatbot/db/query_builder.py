# db/query_builder.py — Bangun query SQL berdasarkan intent & entitas

from config import CHATBOT_CONFIG, PRODUCT_COLUMNS
from db.connection import DatabaseConnection

MAX = CHATBOT_CONFIG["max_results"]
T   = "products"          # nama tabel utama
OI  = "order_items"       # tabel order items


class QueryBuilder:
    """
    Semua query dikembalikan sebagai (sql_string, params_tuple).
    Hanya SELECT — tidak ada INSERT/UPDATE/DELETE.
    """

    def __init__(self, db: DatabaseConnection):
        self.db = db

    # ── Produk dasar ──────────────────────────────────────────────────────────

    def list_all_products(self) -> list[dict]:
        sql = f"""
            SELECT id, name, category, price, rating, sold, description
            FROM {T}
            WHERE is_active = 1
            ORDER BY name
            LIMIT {MAX}
        """
        return self.db.execute_select(sql)

    def product_detail(self, product_name: str) -> list[dict]:
        sql = f"""
            SELECT id, name, category, price, rating, sold, description, image
            FROM {T}
            WHERE is_active = 1
              AND LOWER(name) LIKE %s
            LIMIT 5
        """
        return self.db.execute_select(sql, (f"%{product_name.lower()}%",))

    # ── Sort ──────────────────────────────────────────────────────────────────

    def sort_by_price_asc(self, category: str | None = None) -> list[dict]:
        base, params = self._base_active(category)
        sql = f"{base} ORDER BY price ASC LIMIT {MAX}"
        return self.db.execute_select(sql, params)

    def sort_by_price_desc(self, category: str | None = None) -> list[dict]:
        base, params = self._base_active(category)
        sql = f"{base} ORDER BY price DESC LIMIT {MAX}"
        return self.db.execute_select(sql, params)

    def sort_by_rating_desc(self, category: str | None = None) -> list[dict]:
        base, params = self._base_active(category)
        sql = f"""
            {base}
              AND rating IS NOT NULL
            ORDER BY rating DESC LIMIT {MAX}
        """
        return self.db.execute_select(sql, params)

    def best_seller(self, category: str | None = None) -> list[dict]:
        """
        Produk terlaris = produk yang total quantity-nya paling banyak
        di tabel order_items (gabungan dengan products).
        """
        cat_filter = "AND p.category = %s" if category else ""
        params = (category,) if category else ()
        sql = f"""
            SELECT p.id, p.name, p.category, p.price, p.rating,
                   COALESCE(SUM(oi.quantity), 0) AS total_sold,
                   p.description
            FROM {T} p
            LEFT JOIN {OI} oi ON p.id = oi.product_id
            WHERE p.is_active = 1
            {cat_filter}
            GROUP BY p.id
            ORDER BY total_sold DESC
            LIMIT {MAX}
        """
        return self.db.execute_select(sql, params)

    # ── Filter harga ──────────────────────────────────────────────────────────

    def price_range(
        self,
        price_min: int | None,
        price_max: int | None,
        category: str | None = None,
    ) -> list[dict]:
        conditions = ["is_active = 1"]
        params: list = []

        if price_min is not None:
            conditions.append("price >= %s")
            params.append(price_min)
        if price_max is not None:
            conditions.append("price <= %s")
            params.append(price_max)
        if category:
            conditions.append("LOWER(category) = %s")
            params.append(category.lower())

        where = " AND ".join(conditions)
        sql = f"""
            SELECT id, name, category, price, rating, sold, description
            FROM {T}
            WHERE {where}
            ORDER BY price ASC
            LIMIT {MAX}
        """
        return self.db.execute_select(sql, tuple(params))

    # ── Kategori ──────────────────────────────────────────────────────────────

    def by_category(self, category: str) -> list[dict]:
        sql = f"""
            SELECT id, name, category, price, rating, sold, description
            FROM {T}
            WHERE is_active = 1
              AND LOWER(category) = %s
            ORDER BY name
            LIMIT {MAX}
        """
        return self.db.execute_select(sql, (category.lower(),))

    # ── Daftar nama produk (untuk entity extractor) ───────────────────────────

    def all_product_names(self) -> list[str]:
        sql = f"SELECT name FROM {T} WHERE is_active = 1"
        rows = self.db.execute_select(sql)
        return [r["name"] for r in rows]

    # ── Stok / aktif ──────────────────────────────────────────────────────────

    def check_stock(self, product_name: str) -> list[dict]:
        sql = f"""
            SELECT id, name, category, price,
                   IF(is_active = 1, 'Tersedia', 'Tidak Tersedia') AS status
            FROM {T}
            WHERE LOWER(name) LIKE %s
            LIMIT 5
        """
        return self.db.execute_select(sql, (f"%{product_name.lower()}%",))

    # ── Helper ────────────────────────────────────────────────────────────────

    @staticmethod
    def _base_active(category: str | None) -> tuple[str, tuple]:
        base = f"""
            SELECT id, name, category, price, rating, sold, description
            FROM {T}
            WHERE is_active = 1
        """
        if category:
            base += "  AND LOWER(category) = %s"
            return base, (category.lower(),)
        return base, ()
